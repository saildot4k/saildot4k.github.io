DMS HDD Explorer Installer v1.2
-------------------------------

http://www.dms3.com

- Whats new

  * Fixed small issue with DMS3 v1.0 chips
  * Added support for DMS3+ and DMS4 Lite/Pro modchips.
  * Fixed bug in ELF loader, increasing compatibility
  * Added "force format of boot partition" feature

- Installation Directions

  * Burn the ISO included in this archive.
  * Boot the CD you just burned containing the HDD Explorer installer. 
    You will then be prompted to install HDD Explorer. Select OK to 
    begin installation. 
  * Once installation is complete, boot to HDD explorer by holding 
    START on controller 1 and pressing reset. 
  * Once at the HDD Explorer screen, ensure the HDD Explorer 
    installation CD is in your PS2, and press triangle to install the
    applications which are bundled with the installer cd. 

- Bundled Applications

  * PGEN 1.2 - most recent PGEN build, with HDD support
  * DMS HDD Format tool - allows you to manipulate filesystems on 
    your PS2 HDD. 
  * DMS HDD Dump tool - allows you to copy the contents of a CD to a 
    specified filesystem on the HDD. This is what you will use to get 
    roms onto the HDD for PGEN.
  * Naplink - Run homebrew code on your PS2.
  * ps2link - Run homebrew code on your PS2.
  * ExecFTPS - FTP server for your PS2.
  * SNES-Station - SNES emulator.
  * PS2 MP3 Player - as the name says.
  * PS2Newz Memory Card Killer - brute force format your memory card.

- Miscellaneous

Some people have had their boot partition corrupted and have been unable
to format/erase this partition in order to fix the problem. Now you can
use make the HDD Explorer installer format the boot partition by holding
L1 + L2 + R1 + R2 at the "Press X to install DMS HDD Explorer..." screen.