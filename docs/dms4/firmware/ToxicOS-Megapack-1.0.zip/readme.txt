=====================
ToxicOS MegaPack v1.0
=====================

Compiled by AgentX. Applications copyright their respective authors.

Introduction
------------

ToxicOS 0.4 introduces the ability to both launch and install homebrew ELF files,
similar to capabilities offered by the likes of LaunchELF and CC BootManager. I
have compiled a package of all the best homebrew applications which you can
install with ToxicOS onto your HDD or memory card. In addition to this, my package
contains the ToxicOS updater file and a compatible USBD.IRX file meaning that it
contains all you need to get ToxicOS installed and up and running easily.

How To Use
----------

First, burn the .bin/.cue in this archive to a CD.

* To install ToxicOS (if you have not done so already):
  - Boot the megapack CD like a PS2 game. The ToxicOS update screen will appear.
  - Follow the onscreen directions.

* To install the USBD.IRX driver from the megapack, enabling usbmass support:
  - Load ToxicOS, place the megapack CD in the drive
  - Goto the settings screen, then select "Choose USBD IRX driver"
  - Browse to the cdrom, then select USBD.IRX

* To install the applications in this megapack:
  
  There are two ways to do this:

  From CD
  ~~~~~~~

  1) Load ToxicOS, place the megapack CD in the drive.
  2) Switch to the "Apps" tab, then select "Install" from the toolbar.
  3) Follow the directions, you will be asked to select which applications to
     install. The entire megapack will not fit onto a single 8mb memory card
     so you might not be able to install all the applications. If your free
     space is limited only install the applications you want. If you are
     installing onto a HDD this wont matter as you have up to 128mb for your
     applications.
  4) Once you have chosen your applications the installation process will
     begin. Be patient :)

  From USB Mass storage
  ~~~~~~~~~~~~~~~~~~~~~

  1) Extract the contents of the megapack cd imge (the .bin/.cue files) onto
     your mass storage device. There are many ways to do this, for example
     using ISOBuster or mounting the image with Daemon tools and copying the
     files.
  2) Load ToxicOS.
  3) Switch to the "Browser" tab, select mass:
  4) Navigate to where the megapack files (INSTALL.CNF and directories) are
     stored.
  5) Select the INSTALL.CNF file.
  6) Follow directions 3-4 from above.