DMS HDD Explorer Installer v1.31
--------------------------------

http://www.dms3.com

NOTE: This will most likely be the final release of HDD Explorer. DMS
      Explorer v2 is under development which will replace HDD Explorer.

      As a gift to the scene we have decided to make this release of 
      HDD Explorer available to anybody, regardless of if you are 
      using a DMS product or not. The ELF file is on the install CD :)

- Whats new

  * Seperated HDD Explorer and loader. Now it is possible to load
    any ELF via Devolution 2 mode (HDD Explorer is installed by default).
  * Optional configuration file is supported
  * Compatible with most recent DMS3 and DMS4 flash releases.
  * No longer writes any data to modchip flash which should eliminate
    the problems some people have been reporting. 
  * HDD Explorer is no longer restricted to working on consoles with DMS
    modchips installed. Enjoy! :) 

- Installation Directions

  * Burn the ISO included in this archive.
  * Boot the CD you just burned containing the HDD Explorer installer. 
    You will then be prompted to install HDD Explorer. Select OK to 
    begin installation. 
  * Once installation is complete, boot to HDD explorer by holding 
    START on controller 1 and pressing reset. 
  * Once at the HDD Explorer screen, ensure the HDD Explorer 
    installation CD is in your PS2, and press triangle to install the
    applications which are bundled with the installer cd. 

- Bundled Applications

  * PGEN 1.2 - most recent PGEN build, with HDD support
  * DMS HDD Format tool - allows you to manipulate filesystems on 
    your PS2 HDD. 
  * DMS HDD Dump tool - allows you to copy the contents of a CD to a 
    specified filesystem on the HDD. This is what you will use to get 
    roms onto the HDD for PGEN.
  * Naplink - Run homebrew code on your PS2.
  * ps2link - Run homebrew code on your PS2.
  * ExecFTPS - FTP server for your PS2.
  * SNES-Station - SNES emulator.
  * PS2 MP3 Player - as the name says.
  * PS2Newz Memory Card Killer - brute force format your memory card.

- Advanced Users

With release 1.3 of HDD Explorer the actual HDD Explorer ELF has been
seperated from the loader. This means that you can replace the HDD
Explorer ELF on the HDD with anything you like, and this will be loaded
when you enter Dev.olution 2 mode. The filename of the ELF which is loaded
on startup is "boot.elf", in the partition "__boot". Another way of saying
this is that "hdd:__boot/boot.elf" is loaded on startup. All you need
to do in order to replace HDD Explorer with the application of your choice
is replace this file.

Before loading the boot.elf file, the modchip firmware will attempt to load
an _optional_ configuration file called "boot.cfg" from the same partition 
(so filename "hdd:__boot/boot.cfg". If found it will parse its contents and 
set some options accordingly. The options are as follows:

DISABLE_DEV9 - Disable the network adapter (ethernet and HDD) before loading
               boot.elf. This can be useful if you are loading an ELF which has
               no HDD/ethernet support, or which does not work correctly if the
               network adapter is enabled when the ELF is first loaded.
REMOVE_HOOKS - Remove all traces of the modchip from memory before loading
               boot.elf. This is necessary in order to load certain ELF files
               which hook into system internals.

To enable an option, simply include its corresponding keyword (ie: DISABLE_DEV9)
in the boot.cfg file. One keyword per line.

Lastly, some people have had their boot partition corrupted and have been unable
to format/erase this partition in order to fix the problem. Now you can
use the HDD Explorer installer format the boot partition by holding
L1 + L2 + R1 + R2 at the "Press X to install DMS HDD Explorer..." screen.