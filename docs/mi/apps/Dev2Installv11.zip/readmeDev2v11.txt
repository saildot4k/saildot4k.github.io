
============================
INFINITY DEV2 INSTALLER V1.1
============================

- What's new :

  - Added V12 external hard drive interface compatibility.

  - Enabled loading of BOOT.ELF from the boot path of the
    DEV2I.ELF executable (e.g. to use it from naplink, just
    place DEV2I.ELF and BOOT.ELF in the same directory and
    the BOOT.ELF file will be loaded directly from HOST: ).

    Should work with any launcher program that supports
    correct arguments passing to the launched elf since the
    default path is taken from argv[0];

    If you don't understand any of this, just follow the
    instructions below to burn the installation cd and
    everything will work automatically. ;-)


Instructions :
--------------

This program enables you to install any PS2 executable on your HDD and
lauch it as the default DEV2 program.

To use it :

- Rename the ELF executable that you want to use as BOOT.ELF
- Burn a PS2 cd with all the files included in this archive and your
  selected BOOT.ELF.
- Boot the cd and follow the on-screen instructions.


E.G. to use PS2OS directly from the HDD :

Rename the file PS2OS.ELF as BOOT.ELF and burn a cd with the following
files :

DUMMY.BIN
DUMMY2.BIN
SYSTEM.CNF
DEV2I.ELF
BOOT.ELF

After the installation is complete you can launch PS2OS directly from
your HDD by holding L1 just after reset (or select DEV2 as the default
boot mode in the config screen).
