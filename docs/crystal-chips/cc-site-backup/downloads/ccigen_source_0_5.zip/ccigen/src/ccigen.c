// CCIGEN.EXE (c) 2004 Crystal Chips
//
// Crystal Chips CC1.0 firmware image generator.
//


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ucl/ucl.h>

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;

#define MAX_LOADER_LEN 0x62C
#define MAX_DATA_LEN (4096 - 5)

typedef struct {
    u16 pad;			// 0x00 - 0x01
    u8 len_m1_hi;		// 0x02
    u8 len_m1_lo;		// 0x03
    u8 csum;			// 0x04
    u8 data[MAX_DATA_LEN];
} CC_EEP_Img;

int GenerateEEP_IMG(u8 * lbuf, int llen, u8 * obuf, int olen, CC_EEP_Img * img)
{
    int i;
    u8 csum = 0;

// initialize the data buffer
    for (i = 0; i < sizeof(img->data); i++) { img->data[i] = 0; }

    img->pad = 0;
    img->len_m1_hi = ((llen - 1) >> 8) & 0xFF;
    img->len_m1_lo = ((llen - 1) >> 0) & 0xFF;

    for (i = 0; i < llen; i++) {
	csum += lbuf[i];
	img->data[i] = lbuf[i];
    }
    img->csum = csum;

    *(u16 *) (&(img->data[llen])) = olen & 0xFFFF;
    memcpy(&(img->data[llen + 2]), obuf, olen);

    return (0);
}

void printUsage(void)
{
    printf("usage: ccigen loader_file osdhook_file output_file\n");
}

int main(int argc, char *argv[])
{
    FILE *fp;
    u8 lbuf[0x1000];
    u8 obuf[0x4000];
    u8 pbuf[0x4000];
    int llen, olen, plen;
    CC_EEP_Img img;
    u32 sum;
    int i;

    printf("ccigen v0.05 (c) 2004 Crystal Chips\n");

    if (argc < 4) {
	printUsage();
	return (-1);
    }

    if ((fp = fopen(argv[1], "rb")) == NULL) {
	printf("Unable to open file '%s' for reading!\n", argv[1]);
	return (-2);
    }

    llen = fread(lbuf, 1, 0x1000, fp);
    fclose(fp);

    if (llen > MAX_LOADER_LEN) {
	printf("ERROR: loader length(%d) exceeds maximum allowed length(%d)!\n", llen,
	       MAX_LOADER_LEN);
	return (-3);
    }

    if ((fp = fopen(argv[2], "rb")) == NULL)
    {
    	printf("Unable to open file '%s' for reading!\n", argv[2]);
    	return (-4);
    }

    fseek(fp, 0, SEEK_END); olen = ftell(fp); fseek(fp, 0, SEEK_SET);

    if (fread(obuf, 1, olen, fp) != olen)
    {
        fclose(fp);
        printf("Error reading in file '%s'!\n", argv[2]);
        return(-4);
    }
    fclose(fp);

    plen = MAX_DATA_LEN - (llen + 2);
    if (ucl_nrv2e_99_compress(obuf, olen, pbuf, &plen, NULL, 10, NULL, NULL) != UCL_E_OK)
    {
    	printf("Error during ucl_nrv2b_99_compress.\n");
    	return (-5);
    }

	printf("Packed %d bytes into %d bytes\n", olen, plen);

    if ((llen + plen + 2) > MAX_DATA_LEN)
    { // should never happen unless a bug..
	    printf("ERROR: combined lengths of loader and osdhook binaries exceeds total EEPROM size(%d)!\n",
	     MAX_DATA_LEN);
	    return (-6);
    }

    printf("Creating image...");
    if (GenerateEEP_IMG(lbuf, llen, pbuf, plen, &img) != 0)
    {
    	printf("Error generating image!\n");
    	return (-7);
    }

    sum = 0;
    for (i = 0; i < (0x1000 / 4); i++)	// make a 32-bit XOR sum of the whole thing.
	sum ^= ((u32 *) (&img))[i];

   // printf("File sum: %08X\n", sum);

    if ((fp = fopen(argv[3], "wb")) == NULL)
    {
    	printf("Unable to open file '%s' for writing!\n", argv[3]);
    	return (-8);
    }

    fwrite(&sum, 1, 4, fp);
    fwrite(&img, 1, sizeof(CC_EEP_Img), fp);
    fclose(fp);

    printf("done!\n");
    return (0);
}
